package org.test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.utilities.ForTakeSS;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test1 extends ForTakeSS {

	@Test(groups = "Chrome")
	public void LaunchBrowser() {
		chromeBrowserLaunch();

	}

	@Test(groups = "firefox")
	public void LaunchfirefoxBrowser() {
		firefoxBrowserLaunch();

	}

	@Test(priority = 1, groups = { "Chrome", "firefox" })
	public void tc1() throws InterruptedException, IOException {
		WebElement element = driver.findElement(By.linkText("https://www.getcalley.com/"));
		element.click();
		Thread.sleep(2000);
		ForResolution1();
		TakesScreenshot tc = (TakesScreenshot) driver;
		File source = tc.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\CHAITANYA\\Desktop\\Screenshot\\getcalley1.jpeg");
		FileUtils.copyFile(source, target);
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
		Thread.sleep(3000);
	}

	@Test(priority = 2, groups = { "Chrome", "firefox" })
	public void tc2() throws InterruptedException, IOException {
		driver.findElement(By.partialLinkText("https://www.getcalley.com/calley-call-from-browser/")).click();
		
		TakesScreenshot tc = (TakesScreenshot) driver;
		File source = tc.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\CHAITANYA\\Desktop\\Screenshot\\getcalley2.jpeg");
		FileUtils.copyFile(source, target);
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
	}

	@Test(priority = 3, groups = { "Chrome", "firefox" })
	public void tc3() throws IOException, InterruptedException {
		driver.findElement(By.linkText("https://www.getcalley.com/best-auto-dialer-app/")).click();
		TakesScreenshot tc = (TakesScreenshot) driver;
		File source = tc.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\CHAITANYA\\Desktop\\Screenshot\\getcalley3.jpeg");
		FileUtils.copyFile(source, target);
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
	}

	@Test(priority = 4, groups = { "Chrome", "firefox" })
	public void tc4() throws InterruptedException, IOException {
		driver.findElement(By.partialLinkText("https://www.getcalley.com/best-auto-dialer-app/")).click();
		TakesScreenshot tc = (TakesScreenshot) driver;
		File source = tc.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\CHAITANYA\\Desktop\\Screenshot\\getcalley4.jpeg");
		FileUtils.copyFile(source, target);
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
	}

	@Test(priority = 5, groups = { "Chrome", "firefox" })
	public void tc5() throws IOException, InterruptedException {
		driver.findElement(By.linkText("https://www.getcalley.com/how-calley-auto-dialer-app-works/")).click();
		TakesScreenshot tc = (TakesScreenshot) driver;
		File source = tc.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\CHAITANYA\\Desktop\\Screenshot\\getcalley5.jpeg");
		FileUtils.copyFile(source, target);
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
		driver.quit();
	}

}
