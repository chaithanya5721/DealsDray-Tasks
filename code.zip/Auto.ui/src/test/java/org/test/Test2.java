package org.test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test2 {
	public static void main(String[] args) throws InterruptedException, IOException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.dealsdray.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("prexo.mis@dealsdray.com");
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("prexo.mis@dealsdray.com");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div[(@class='css-sukebr')]//child::button)[1]")).click();
		driver.findElement(By.xpath("(//div[(@class='expansion-panel submenu')]//child::button)[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Add Bulk Orders']")).click();
		Thread.sleep(5000);
		WebElement upload_file = driver.findElement(By.xpath("//input[@type='file']"));
		upload_file.sendKeys("D:\\Downloads\\Upload\\demo-data.xlsx");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[text()='Import']")).click();
		driver.findElement(By.xpath("//button[text()='Validate Data']")).click();
		Thread.sleep(7000);
		Alert a = driver.switchTo().alert();
		a.accept();
		Thread.sleep(7000);
		TakesScreenshot tc = (TakesScreenshot)driver;
		File source = tc.getScreenshotAs(OutputType.FILE);
		File target = new File("D:\\Downloads\\Upload\\Test2.jpeg");
		FileUtils.copyFile(source, target);
		driver.findElement(By.xpath("//button[text()='Submit']")).click();
		Thread.sleep(4000);
		Alert a1 = driver.switchTo().alert();
		a1.accept();
		driver.quit();
		
	}
}
